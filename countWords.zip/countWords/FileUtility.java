package com.countwords;
/*
 * Class Name : FileUtility.Java
 * Date of Creation : 17-03-2022
 * Description : File Utility which contain business logic as per business configuration value
 * */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileUtility {
	
	
	public List<String> retMatWordListAndDispWordsAndTCnt(char charToMatch, int minLength) throws IOException 
	{
		String recordLine = null;
		String separator = ConstantConfig.separator;
		
		//We will read input from file.
		//(If in case file very big/multiple files, multi-threading can also be implemented to read input records and process them. )
		FileReader inputfile;
		BufferedReader reader;
		try 
		  {
			   inputfile = new FileReader(ConstantConfig.inputFilePath);
			   reader = new BufferedReader(inputfile);
			   
	  	   } 
		 catch (IOException e) 
		   {
			throw e;
 		   }
		 catch (Exception e)
		   {
			throw e;
		   }
		
	ArrayList<String> matchingWordList = new ArrayList<String>();
		
		while((recordLine = reader.readLine()) != null)
		{
			String wordsArray[] = recordLine.split(separator);
			
		for( String words : wordsArray) 
			{
			//	if((words[i].charAt(0) == charToMatch || words[i].charAt(0) == (charToMatch + 32)) // small letter and capital letter charactor
				//		&& words[i].length() >= minLength)
				boolean charMatch = false;
				if(charToMatch >= 97)
				{//If char to match is lower case letter
					charMatch = (words.charAt(0) == charToMatch || words.charAt(0) == (charToMatch - 32))?true:false;
				}
				else
				{//If char to match is Upper case letter
					charMatch = (words.charAt(0) == charToMatch || words.charAt(0) == (charToMatch + 32))?true:false;
				}
				if(charMatch && words.length() > minLength ) // If Business rule requirement match then only add into matchList
				{
					matchingWordList.add(words);
				}
			}
		}
		
		if (matchingWordList != null) 
		{
			// As per requirement, Need to display total count and words in same call.
			System.out.println(matchingWordList.size());
			for (String word : matchingWordList) 
			  { 		      
		           System.out.println(word); 		
		      }
			
		} 
		return matchingWordList;  /*As per problem statement, method should return 2 result which is not possible but still return list which contain both output from problem statement*/
	}
 
}
