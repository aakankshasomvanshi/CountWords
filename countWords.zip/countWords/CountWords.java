package com.countwords;

/*
 * Class Name : CountWords.Java
 * Date of Creation : 17-03-2022
 * Description : Entry point of Project and calling utility method which is use for count matching word and printing same
 *  * */

import java.io.IOException;
import java.util.ArrayList;

public class CountWords {

	public static void main(String[] args) {
		
		FileUtility fileUtility = new FileUtility();
		ArrayList<String> finalMatchingWordList = null; /*currently we are not using this value anywhere but in future we can use */

		try 
		{
			/* Calling 'returnMatchWordListAndDispWordsAndTotalCount' method by passing business rule defined value */
			finalMatchingWordList = (ArrayList<String>) fileUtility.retMatWordListAndDispWordsAndTCnt(
					ConstantConfig.startWordFrom, ConstantConfig.minWordLenth);
		} catch (Exception e) {
			System.out.println(ConstantConfig.fileNotFoundExceptionMessage
					+ ConstantConfig.inputFilePath);
		}
	}
}
